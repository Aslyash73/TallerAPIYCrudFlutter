class Rutas {
  static String dirServerListar =
      "https://danielparking.000webhostapp.com/?controlador=cliente&accion=listar";
  static String dirServerEliminar =
      "https://danielparking.000webhostapp.com/?controlador=cliente&accion=eliminar";
  static String dirServerEditar =
      "https://danielparking.000webhostapp.com/?controlador=cliente&accion=editar";
  static String dirServerRegistrar =
      "https://danielparking.000webhostapp.com/?controlador=cliente&accion=registrar";
}
